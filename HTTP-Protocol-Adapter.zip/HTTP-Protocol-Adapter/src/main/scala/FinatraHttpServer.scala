package main.scala

import com.twitter.finagle.http.{ Request, Response }
import com.twitter.finatra.http.HttpServer
import com.twitter.finatra.http.filters.{ ExceptionMappingFilter, CommonFilters, LoggingMDCFilter, TraceIdMDCFilter }
import com.twitter.finatra.http.routing.HttpRouter
import org.slf4j.LoggerFactory
import ch.qos.logback.core.util.StatusPrinter
import ch.qos.logback.classic.LoggerContext

object FinatraHttpServerMain extends FinatraHttpServer

class FinatraHttpServer extends HttpServer {

  override val defaultFinatraHttpPort: String = ":8080"

  override val modules = Seq()

  override def configureHttp(router: HttpRouter) {
    router
      .filter[ExceptionMappingFilter[Request]]
      .add[BasicAuthFilter, KafkaController]    //add controller as per the requirement
      .exceptionMapper[AccessDeniedExceptionMapper]
  }
}
