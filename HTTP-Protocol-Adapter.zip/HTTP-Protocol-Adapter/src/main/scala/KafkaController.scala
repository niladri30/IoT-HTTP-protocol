package main.scala
import com.twitter.finagle.http.Request
import scala.util.{ Failure, Success, Try }
import com.twitter.finatra.http.Controller
import com.twitter.util.Future
import org.slf4j.LoggerFactory
import ch.qos.logback.core.util.StatusPrinter
import ch.qos.logback.classic.LoggerContext
import scala.io.Source
import java.util.Properties
import java.io.FileInputStream
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import java.util.Calendar
import java.text.SimpleDateFormat
import java.util.TimeZone
import org.apache.kafka.clients.producer.{ KafkaProducer, ProducerRecord, RecordMetadata, Callback }

class KafkaController extends Controller {
  private[this] var topic = "hdfs";
  private[this] var generic_topic = "hdfs";
  private[this] var new_topic = "test";
  private[this] var new1_topic = "test";
  private[this] var new2_topic = "test";
  private[this] var new3_topic = "test";

  private[this] val logger = LoggerFactory.getLogger("ProtocolAdapater-HTTP");

  def LoadProps(): Properties = {
    val props = new Properties();
    try {
      props.load(new FileInputStream("./src/main/resources/kafka_config.properties"));
      logger.info("Picking up Kafka details from property file");

      /**
       * Read from Property files
       * generic_topic = props.getProperty("generic_topic");
       * new_topic = props.getProperty("new_topic");
       * new1_topic = props.getProperty("new1_topic");
       * new2_topic = props.getProperty("new2_topic");
       * new3_topic = props.getProperty("new3_topic");
       * logger.info("Generic Topic value from property file : " + generic_topic);
       * logger.info("New Topic value from property file : " + new_topic);
       * logger.info("New1 Topic value from property file : " + new1_topic);
       * logger.info("New2 Topic value from property file : " + new2_topic);
       * logger.info("New3 Topic value from property file : " + new3_topic);
       */
      generic_topic = props.getProperty("generic_topic");
      logger.info("Kafka Servers : " + props.getProperty("bootstrap.servers"))

    } catch {
      case e: Exception =>
        logger.error("Error reading config values");
    }
    return props;
  }

  private[this] val producer = new SimpleKafkaProducer[String, String](LoadProps())

  

  post("neel/ingest") { request: Request =>
    {
      logger.info("Request Header : " + request.headerMap + ", Request Payload : " + request.getContentString())
      try {
        logger.debug("Request Received : " + request.getContentString())
        var result = producer.sendWithCallback(generic_topic, request.getContentString());
        if (!result.toString().contains("Failure")) {
          logger.info("Posted to topic: " + generic_topic);
          response.ok
        } else {
          logger.error("Protocol Adapter txn resulted in error");
          response.internalServerError;
        }
      } catch {
        case e: Exception =>
          logger.error("Protocol Adapter txn resulted in error");
          response.internalServerError;
      }
      
    }
  }

  

  get("/search") { request: Request =>
    var query1 = request.params.getAll("Name");
    var query2 = request.params.toString();
    Future.value("Name List : " + query1 + "\n" + "Query Parameters Passed :" + query2);
  }

  post("neel/ingest/csv") { request: Request =>

    val data = request.contentString;
    var message = "";
    var i = 1;
    var validcsv = true;

    for (line <- data.split("\n")) {
      message = validateComma(line);
      if (message != "OK") {
        validcsv = false;
      }
      i = i + 1;
    }

    if (validcsv) {
      try {
        var result = producer.sendWithCallback(generic_topic, request.getContentString());
        if (!result.toString().contains("Failure")) {
          logger.info("Posted to topic: " + generic_topic);
          response.ok.body("")
        } else {
          logger.error("Protocol Adapter resulted in error");
          response.internalServerError;
        }
      } catch {
        case e: Exception =>
          logger.error("Protocol Adapter resulted in error");
          response.internalServerError;
      }
    } else {
      logger.error("Not a well formed CSV Document - CSV : " + request.getContentString());
      logger.info("Protocol Adapter txn completed with validation errors");
      response.badRequest("Not a well formed CSV Document");
    }
  }

  def validateComma(input: String): String =
    {

      var message: String = "";
      val cols = input.split(",").map(_.trim);
      val length = cols.length;
      if (cols(0).isEmpty())
        message = "Empty Timestamp";
      else if (cols(1).isEmpty())
        message = "Empty Parameter Name";
      else if (length < 3)
        message = "Empty Parameter Value";
      else
        message = "OK";
      if (message != "OK") {
        logger.info("Error : " + message);
      }
      return message;

    }
  
  def PostToKafka(topic: String , message : String)
  {
    try {
          logger.info("Trying to Post to Topic : " + topic)
          var result = producer.sendWithCallback(topic, message);
          if (!result.toString().contains("Failure")) {
            logger.info("Posted to topic: " + topic);
            response.ok
          } else {
            logger.error("Unable to Post to Topic : " + topic);
            response.internalServerError;
          }

        } catch {
          case e: Exception =>
            logger.error("Protocol Adapter resulted in error");
            response.internalServerError;
        }
  }

}

