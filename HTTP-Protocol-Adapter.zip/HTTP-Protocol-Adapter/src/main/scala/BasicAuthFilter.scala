package main.scala

import com.twitter.finagle.SimpleFilter
import com.twitter.finagle.Service
import com.twitter.finagle.http.Request
import com.twitter.util.Future
import com.twitter.finagle.http.Response
import org.slf4j.LoggerFactory
import ch.qos.logback.core.util.StatusPrinter
import ch.qos.logback.classic.LoggerContext
import com.twitter.finatra.http.response.ResponseBuilder

class AccessDeniedException extends Exception
class FormatValidationException extends Exception
class EmptyPayloadException extends Exception

class BasicAuthFilter extends SimpleFilter[Request, Response] {

  override def apply(request: Request, service: Service[Request, Response]): Future[Response] = {

    def logger = LoggerFactory.getLogger("ProtocolAdapater-HTTP")
    var host = request.headerMap.get("Host").toString()
    var content = request.headerMap.get("Content-Type")
    logger.info("Received message of Size : " + request.getContentString().getBytes.length + " Bytes From " + host + ", Content-Type : " + content)
    logger.debug("Request Header : " + request.headerMap + ", Request Payload : " + request.getContentString())

    /**if ((request.headerMap.get("Authorization").getOrElse("") != "test")&&((request.headerMap.get("Authorization").getOrElse("") != "TrakM8"))) {
      *Future.exception(new AccessDeniedException)
    *} else */ if ((request.getContentString()).isEmpty) {
      Future.exception(new EmptyPayloadException)
    } else {
      service(request)
    }
  }
}
