package main.scala

import com.google.inject.Inject
import com.twitter.finatra.http.response.ResponseBuilder
import com.twitter.finagle.http.Request
import com.twitter.finagle.http.Response
import com.twitter.finatra.http.exceptions.ExceptionMapper

class AccessDeniedExceptionMapper @Inject() (response: ResponseBuilder)
    extends ExceptionMapper[main.scala.AccessDeniedException] {

  override def toResponse(request: Request, exception: AccessDeniedException): Response = {
    response.forbidden("Access Forbidden. Invalid Authorization Header")
  }
}