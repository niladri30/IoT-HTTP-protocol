package main.scala

import java.util.concurrent.{ Future => JFuture }
import java.util.concurrent.{ ExecutionException, TimeUnit }
import scala.util.{ Failure, Success, Try }
import com.twitter.finagle.http.Response
import org.slf4j.LoggerFactory
import ch.qos.logback.core.util.StatusPrinter
import ch.qos.logback.classic.LoggerContext
import java.util.Properties

import org.apache.kafka.clients.producer.{ KafkaProducer, ProducerRecord, RecordMetadata, Callback }

class SimpleKafkaProducer[K, V](properties: Properties) {

  private lazy val producer = new KafkaProducer[K, V](properties)

  def send(topic: String, value: V): JFuture[RecordMetadata] = producer.send(new ProducerRecord[K, V](topic, value))

  def sendWithCallback(topic: String, value: V): JFuture[RecordMetadata] = {

    def logger = LoggerFactory.getLogger("ProtocolAdapater-HTTP")

    producer.send(new ProducerRecord[K, V](topic, value), new Callback {

      override def onCompletion(metadata: RecordMetadata, exception: Exception): Unit = {

        var result =
          if (exception == null) {
            //logger.info(metadata.topic())
            Success(metadata)
          } else {
            logger.error("Exception : " + exception.getMessage)
            Failure(exception)
          }

      }
    })

  }

  def close = producer.close
}