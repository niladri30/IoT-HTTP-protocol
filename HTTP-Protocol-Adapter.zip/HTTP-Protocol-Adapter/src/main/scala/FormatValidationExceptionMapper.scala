package main.scala

import com.google.inject.Inject
import com.twitter.finatra.http.response.ResponseBuilder
import com.twitter.finagle.http.Request
import com.twitter.finagle.http.Response
import com.twitter.finatra.http.exceptions.ExceptionMapper

class FormatValidationExceptionMapper @Inject()(response: ResponseBuilder)
      extends ExceptionMapper[main.scala.FormatValidationException] {

      override def toResponse(request: Request, exception: FormatValidationException): Response = {
          response.internalServerError("Error Parsing Input JSON")  
      }  
}