package main.scala
import java.util.Properties

object PropGen {
  def fromMap(m: Map[String, String]): Properties =
    m.foldLeft(new Properties()) { case (properties, (k, v)) =>
      properties.put(k, v)
      properties
    }
}
